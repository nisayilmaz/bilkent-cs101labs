public class App {
    public static void main(String[] args) throws Exception {
        System.out.println("Hello, My name is Nisa.I'm a cs student in Bilkent University. I hope you are having a wonderful day! :) ");
    }
}
