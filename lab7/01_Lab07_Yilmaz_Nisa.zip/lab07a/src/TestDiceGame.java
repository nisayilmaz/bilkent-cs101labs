public class TestDiceGame {
    public static void main(String[] args){
        DiceGame game = new DiceGame();
        
        System.out.println(game.play() + " times to get (6 , 6) ");
    }
    
}
